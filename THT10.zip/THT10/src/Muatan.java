public interface Muatan {
    double kapasitasMuatan(); // dalam kg

}
