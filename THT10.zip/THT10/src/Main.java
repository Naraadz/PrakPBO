public class Main {
    public static void main(String[] args) {
         Kendaraan[] daftarKendaraan = {
            new MobilPribadi("H48IN", "BYD", 2025),
            new Bus("G40N", "Mercedes", 2020),
            new Truk("JO073ON", "Hino", 2019, 5000)
        };

         for (Kendaraan k : daftarKendaraan) {
            k.tampilkanInfo();
            System.out.println("Biaya Sewa 3 hari : Rp" + k.hitungBiayaSewa(3));
            System.out.println("Perlu Supir       : " + (k.perluSupir() ? "Ya" : "Tidak"));
            if (k instanceof Muatan) {
                System.out.println("Kapasitas Muatan  : " + ((Muatan) k).kapasitasMuatan() + " kg");
            }
            System.out.println("-------------");
        }
    }
}