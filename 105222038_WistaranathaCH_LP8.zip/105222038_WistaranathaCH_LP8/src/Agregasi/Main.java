package Agregasi;

import java.util.ArrayList;

class Mahasiswa {
    String nama;

    Mahasiswa(String nama) {
        this.nama = nama;
    }
}

class Universitas {
    String namaUniv;
    ArrayList<Mahasiswa> daftarMahasiswa = new ArrayList<>();

    Universitas(String namaUniv) {
        this.namaUniv = namaUniv;
    }

    void tambahMahasiswa(Mahasiswa mahasiswa) {
        daftarMahasiswa.add(mahasiswa);
    }

    void tampilkanMahasiswa() {
        System.out.println("Daftar mahasiswa di " + namaUniv + ":");
        for (Mahasiswa mahasiswa : daftarMahasiswa) {
            System.out.println("- " + mahasiswa.nama);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa("Remi");
        Mahasiswa mhs2 = new Mahasiswa("Chu");

        Universitas uper = new Universitas("Universitas Pertamina");
        uper.tambahMahasiswa(mhs1);
        uper.tambahMahasiswa(mhs2);

        uper.tampilkanMahasiswa();
    }
}
