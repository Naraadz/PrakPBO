class Animal {
    void makeSound() {
        System.out.println("Animal sound");
    }
}

class Mammal extends Animal {
    @Override
    void makeSound() {
        System.out.println("Mammal sound");
    }
}

class Reptile extends Animal {
    @Override
    void makeSound() {
        System.out.println("Reptile sound");
    }
}

class Dog extends Mammal {
    @Override
    void makeSound() {
        System.out.println("Dog barking");
    }
}
