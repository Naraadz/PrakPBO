package PemesananTiket;

public class Bus extends Transportasi {
    public Bus(String nama, int jumlahKursi, String tujuan) {
        super(nama, jumlahKursi, tujuan);
    }

    @Override
    public double hitungHargaTiket() {
        return 100000 * 1.10;
    }

    @Override
    public double hitungHargaTiket(String kelasLayanan) {
        double harga = hitungHargaTiket();
        switch (kelasLayanan.toLowerCase()) {
            case "Bisnis": 
                return harga * 1.25;

            case "VIP": 
                return harga * 1.5;

            default: return harga;
        }
    }
}
