package PemesananTiket;

public class Kereta extends Transportasi {
    public Kereta(String nama, int jumlahKursi, String tujuan) {
        super(nama, jumlahKursi, tujuan);
    }

    @Override
    public double hitungHargaTiket() {
        return 100000 * 1.20;
    }

    @Override
    public double hitungHargaTiket(String kelasLayanan) {
        double harga = hitungHargaTiket();
        switch (kelasLayanan.toLowerCase()) {
            case "Bisnis": 
                return harga * 1.2;

            case "VIP": 
                return harga * 1.4;

            default: return harga;
        }
    }
}
