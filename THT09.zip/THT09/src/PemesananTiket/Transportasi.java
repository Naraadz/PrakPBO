package PemesananTiket;

public abstract class Transportasi {
    private String nama;
    private int jumlahKursi;
    private String tujuan;

    public Transportasi(String nama, int jumlahKursi, String tujuan) {
        this.nama = nama;
        this.jumlahKursi = jumlahKursi;
        this.tujuan = tujuan;
    }

    public String getNama() {
        return nama;
    }

    public abstract double hitungHargaTiket();
    public abstract double hitungHargaTiket(String kelasLayanan);
}
