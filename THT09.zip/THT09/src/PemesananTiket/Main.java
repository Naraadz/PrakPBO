package PemesananTiket;

public class Main {
    public static void main(String[] args) {

        Transportasi[] transportasiList = new Transportasi[3];
        transportasiList[0] = new Bus("Bus ke Bekasi", 60, "Bekasi");
        transportasiList[1] = new Kereta("Kereta ke Yogyakarta", 150, "Yogyakarta");
        transportasiList[2] = new Pesawat("Pesawat ke Bali", 130, "Bali");

        for (Transportasi t : transportasiList) {
            System.out.println(t.getNama() + " - Harga tiket (default): " + String.format("%.2f", t.hitungHargaTiket()));
        }

        System.out.println();

        System.out.println(transportasiList[0].getNama() + " - Harga tiket (Bisnis): " + 
            String.format("%.2f", transportasiList[0].hitungHargaTiket("Bisnis")));

        System.out.println(transportasiList[1].getNama() + " - Harga tiket (VIP): " +
            String.format("%.2f", transportasiList[1].hitungHargaTiket("VIP"))); 
        
        System.out.println(transportasiList[2].getNama() + " - Harga tiket (Ekonomi): " +
            String.format("%.2f", transportasiList[2].hitungHargaTiket("Ekonomi")));
    }
}
