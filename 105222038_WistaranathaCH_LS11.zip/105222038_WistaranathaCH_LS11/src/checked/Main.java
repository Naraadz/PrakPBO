package checked;

import java.io.*;

class InvalidBookIDException extends Exception {
    public InvalidBookIDException(String message) {
        super(message);
    }
}

class InvalidLoanDurationException extends Exception {
    public InvalidLoanDurationException(String message) {
        super(message);
    }
}

public class Main {

    static final String[] VALID_BOOK_IDS = {"B001", "B002", "B003"};

    public static void main(String[] args) {
        BufferedReader reader = null;

        try {
            FileReader file = new FileReader("src/checked/data.txt");
            reader = new BufferedReader(file);

            String nama = reader.readLine();
            String idBuku = reader.readLine();
            int lamaPinjam = Integer.parseInt(reader.readLine());

            if (!isValidBookID(idBuku)) {
                throw new InvalidBookIDException("ID buku tidak valid!");
            }

            if (lamaPinjam < 1 || lamaPinjam > 14) {
                throw new InvalidLoanDurationException("Lama peminjaman harus antara 1 - 14 hari.");
            }

            System.out.println("Peminjaman berhasil!");
            System.out.println("Nama: " + nama);
            System.out.println("ID Buku: " + idBuku);
            System.out.println("Lama Peminjaman: " + lamaPinjam + " hari");

        } catch (InvalidBookIDException | InvalidLoanDurationException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat membaca file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Format angka tidak valid pada lama peminjaman.");
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
                System.out.println("Program selesai.");
            } catch (IOException e) {
                System.out.println("Gagal menutup file.");
            }
        }
    }

    static boolean isValidBookID(String id) {
        for (String validID : VALID_BOOK_IDS) {
            if (validID.equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
}
