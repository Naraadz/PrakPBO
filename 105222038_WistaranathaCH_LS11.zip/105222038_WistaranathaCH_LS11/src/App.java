public class App {
    public static void main(String[] args) throws Exception {
        int[] angka = { 1, 2, 3};

        try {
            System.out.println(angka[5]); // indeks diluar batas array
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(("Terjadi kesalahan " +e.getMessage()));
        }

        try {
            int hasil = 10 / 0; // pembagi dengan nol (0)
            System.out.println(("Hasil: " + hasil)); 
        } catch (ArithmeticException e) {
            System.out.println("Tidak dapat membagi dengan nol (0): " + e.getMessage());
        }
    }
}
