package Mahasiswa;

public class Mahasiswa {
    private String nama;
    private String NIM;
    
    Mahasiswa(String nama, String NIM) {
        this.nama =  nama;
        this.NIM = NIM;
    }

    public String getNama() {
        return this.nama;
    }

    public String getNIM() {
        return this.NIM;
    }
}
