package Dosen;

public class Dosen {
    private String nama;
    private String NIDN;

    Dosen(String nama, String NIDN) {
        this.nama =  nama;
        this.NIDN = NIDN;
    }

    public String getNama() {
        return this.nama;
    }

    public String getNIDN() {
        return this.NIDN;
    }
}
 