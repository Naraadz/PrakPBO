package Main;

import Dosen.Dosen;
import Mahasiswa.Mahasiswa;
import MataKuliah.MataKuliah;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Dosen dosen1 = new Dosen("Dr. Cahya", "123456");
        Dosen dosen2 = new Dosen("Dr. Budi", "654321");

        Mahasiswa mhs1 = new Mahasiswa("Tiara dan Diana", "212209");
        Mahasiswa mhs2 = new Mahasiswa("Tiara dan Diana", "123768");
        Mahasiswa mhs3 = new Mahasiswa("Tiara", "7631293");

        ArrayList<Dosen> daftarPengampu = new ArrayList<>();
        daftarPengampu.add(dosen1);
        daftarPengampu.add(dosen2);

        ArrayList<Mahasiswa> daftarMahasiswa = new ArrayList<>();
        daftarMahasiswa.add(mhs1);
        daftarMahasiswa.add(mhs2);
        daftarMahasiswa.add(mhs3);

        MataKuliah mk1 = new MataKuliah("PBO", "123");
        mk1.setPengampu(daftarPengampu);
        mk1.setDaftarMahasiswa(daftarMahasiswa);

        tampilkanData(mk1);
    }

    public static void tampilkanData(MataKuliah matakuliah) {
        System.out.println("Mata Kuliah: " + matakuliah.getNama());
        System.out.println("Kode MK: " + matakuliah.getKodeMK());

        System.out.println("\nPengampu");
        for (Dosen d : matakuliah.getPengampu()) {
            System.out.println("- " + d.getNama() + " (NIDN: " + d.getNIDN() + ")");
        }

        System.out.println("\nDaftarMahasiswa");
        for (Mahasiswa m : matakuliah.getDaftarMahasiswa()) {
            System.out.println("- " + m.getNama() + " (NIM: " + m.getNIM() + ")");
        }
    }  
}
