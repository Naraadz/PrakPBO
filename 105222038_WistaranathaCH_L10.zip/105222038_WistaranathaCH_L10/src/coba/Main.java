package coba;

public class Main {
    public static void main(String[] args) {
        Smartphone hp = new Smartphone();

        hp.hidupkan();
        hp.cekBattery();

        Gadget.info();
    }

}
