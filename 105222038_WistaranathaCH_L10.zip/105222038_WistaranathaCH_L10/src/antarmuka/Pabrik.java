package antarmuka;

public interface Pabrik {
    void produksiKendaraan();

}
