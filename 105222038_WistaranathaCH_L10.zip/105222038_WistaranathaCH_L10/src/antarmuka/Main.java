package antarmuka;

public class Main {
    public static void main(String[] args) {
        Mobil m = new Mobil("Cen");
        m.produksiKendaraan();
        m.nyalakanMesin();
        m.matikanMesin();
        m.PemilikKendaraan();
    }

}
