package antarmuka;

public interface Kendaraan {
    public void nyalakanMesin();
    
    public void matikanMesin();
}