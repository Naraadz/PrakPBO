package universitas;

public class Mahasiswa {
    private String NIM;
    private String nama;
    private String Prodi;
    private double IPK;

    public Mahasiswa(String nim, String nama, String prodi, double ipk) {
        this.NIM = nim;
        this.nama = nama;
        this.Prodi = prodi;
        this.IPK = ipk;
    }

    public double getIpk() {
        return IPK;
    }

    public void tampilkanData() {
        System.out.println("---Data Mahasiswa---");
        System.out.println("NIM   : " + NIM);
        System.out.println("Nama  : " + nama);
        System.out.println("Prodi : " + Prodi);
        System.out.println("IPK   : " + IPK);
        System.out.println("---------------------");
    }
}