package Librarysystem;

public class Pengguna {
    private String nama;
    private String IDUser;

    public Pengguna(String nama, String idUser) {
        this.nama = nama;
        this.IDUser = idUser;
    }

    public void pinjamBuku(Buku buku) {
        if (!buku.isDipinjam()) {
            buku.pinjamBuku();
            System.out.println(nama + " meminjam buku: " + buku.getJudul());
        } else {
            System.out.println("Buku " + buku.getJudul() + " sedang dalam peminjaman.");
        }
    }

    public void kembalikanBuku(Buku buku) {
        if (buku.isDipinjam()) {
            buku.kembalikanBuku();
            System.out.println(nama + " pengembalian buku: " + buku.getJudul());
        } else {
            System.out.println("Buku " + buku.getJudul() + " tidak sedang dalam peminjaman.");
        }
    }
}
