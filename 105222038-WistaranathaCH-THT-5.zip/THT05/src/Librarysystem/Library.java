package Librarysystem;

public class Library {
    private Buku[] koleksiBuku;
    private int jumlahBuku;

    public Library(int kapasitas) {
        this.koleksiBuku = new Buku[kapasitas]; 
        this.jumlahBuku = 0;
    }

    public void tambahBuku(Buku buku) {
        if (jumlahBuku < koleksiBuku.length) {
            koleksiBuku[jumlahBuku] = buku;
            jumlahBuku++;
        } else {
            System.out.println("Perpustakaan penuh, tidak dapat menambah buku lagi.");
        }
    }

    public void tampilkanBuku() {
        System.out.println("Daftar Buku di Perpustakaan:");
        for (int i = 0; i < jumlahBuku; i++) {
            koleksiBuku[i].tampilkanInfo();
        }
    }
}
