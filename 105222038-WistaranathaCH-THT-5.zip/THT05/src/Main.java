import Librarysystem.*;

public class Main {
    public static void main(String[] args) {
        Library library = new Library(5);

        Buku buku1 = new Buku("Hello Cello", "Nadia Ristivani", 2023);
        Buku buku2 = new Buku("Laut Bercerita", "Leila S. Chudori", 2017);
        library.tambahBuku(buku1);
        library.tambahBuku(buku2);

        library.tampilkanBuku();

        Pengguna pengguna1 = new Pengguna("Taesan", "1234567890");

        pengguna1.pinjamBuku(buku1);
        library.tampilkanBuku();

        pengguna1.kembalikanBuku(buku1);
        library.tampilkanBuku();
    }
}
