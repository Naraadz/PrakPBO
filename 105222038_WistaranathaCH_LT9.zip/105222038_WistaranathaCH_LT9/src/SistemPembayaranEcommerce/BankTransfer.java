package SistemPembayaranEcommerce;

public class BankTransfer extends PaymentMethod {
    @Override
    public void processPayment(double amount) {
        System.out.println("BankTransfer: is Processing " + amount + " default currency.");
    }

    @Override
    public void processPayment(double amount, String currency) {
        System.out.println("BankTransfer: is Processing " + amount + " in " + currency + ".");
    }
}
