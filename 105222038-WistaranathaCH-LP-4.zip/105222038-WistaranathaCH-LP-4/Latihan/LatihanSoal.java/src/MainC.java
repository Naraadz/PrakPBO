public class MainC {
    public static void main(String[] args) {

        Car car1 = new Car("AB 1234 CRA", "Honda Civic", 250000);
        Car car2 = new Car("B 5678 BE", "Honda NXS", 300000);

        car1.tampilkanInfo();
        car2.tampilkanInfo();

        System.out.println(car1.getNomorPlat());
        System.out.println(car1.getBrand());
        System.out.println(car1.getHargaSewaPerHari());

        car1.setTersedia(false);
        System.out.println("Status Car: " + (car1.isTersedia() ? "Tersedia" : "Tidak Tersedia"));

        Pembeli pembeli1 = new Pembeli("Vernon Chwe", "7216391729412", "08123456789");
        pembeli1.tampilkanInfo();

        Sewa sewa1 = new Sewa(pembeli1, car1, 7);
        sewa1.tampilkanStruk();

        System.out.println("\n=== Status Car Setelah Disewa ===");
        car1.tampilkanInfo();
        car2.tampilkanInfo();
    }
}
