public class Main {
    public static void main(String[] args) {
        // Membuat object dari class Mahasiswa
        // Mahasiswa mh1 = new Mahasiswa ("Rey", "12345", "Teknik Kimia");


        Mahasiswa mhs1 = new Mahasiswa();
        mhs1.nama = "Rey";
        mhs1.nim = "12345";
        mhs1.jurusan = "Teknik Kimia";
        mhs1.belajar();

        Mahasiswa.kuliah();
        System.out.println(Mahasiswa.angkatan);

        // Mencetak nama, nim, jurusan dari object mhs1
        System.out.println(mhs1.nama);
        System.out.println(mhs1.nim);
        System.out.println(mhs1.jurusan);

        mhs1.nama = "Budi";
        System.out.println(mhs1.nama);

        mhs1.belajar();
        mhs1.belajar("Rin");
       
        // Membuat objek dari class mahasiswa
        // Mahasiswa mhs2 = new Mahasiswa("Len", "65432", "Teknik Mesin");
       
        Mahasiswa mhs2 = new Mahasiswa();
        mhs2.nama = "Len";
        mhs2.nim = "65432";
        mhs2.jurusan = "Teknik Mesin";
        mhs2.belajar(); 

    }
} 
