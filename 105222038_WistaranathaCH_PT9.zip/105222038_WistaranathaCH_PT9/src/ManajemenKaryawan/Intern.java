package ManajemenKaryawan;

public class Intern extends Employee {

    public Intern(String name) {
        super(name);
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        double base = 300000;
        return withBonus ? base + 500000 : base;
    }

    @Override
    public void showData() {
        super.showData();
        System.out.println("Position: Intern");
    }
}
