package ManajemenKaryawan;

public abstract class Employee {
    protected String name;

    public Employee(String name) {
        this.name = name;
    }

    public abstract double calculateSalary(boolean withBonus);

    public void showData() {
        System.out.println("name: " + name);
    }

    public String getName() {
        return name;
    }
}
