package ManajemenKaryawan;

public class SoftwareEngineer extends Employee {

    public SoftwareEngineer(String name) {
        super(name);
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        double base = 100000;
        return withBonus ? base + 200000 : base;
    }

    @Override
    public void showData() {
        super.showData();
        System.out.println("Position: Software Engineer");
    }
}
