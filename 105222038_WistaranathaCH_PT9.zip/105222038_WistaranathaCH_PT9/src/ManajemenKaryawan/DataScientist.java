package ManajemenKaryawan;

public class DataScientist extends Employee {

    public DataScientist(String name) {
        super(name);
    }

    @Override
    public double calculateSalary(boolean withBonus) {
        double base = 120000;
        return withBonus ? base + 250000 : base;
    }

    @Override
    public void showData() {
        super.showData();
        System.out.println("Position: Data Scientist");
    }
}
