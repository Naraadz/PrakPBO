package ManajemenKaryawan;

public class Main {
    public static void main(String[] args) {
        Employee[] employees = {
            new SoftwareEngineer("Cae"),
            new DataScientist("Kate"),
            new Intern("Dan")
        };

        System.out.println("=== Data Karyawan (with Bonus) ===");
        for (Employee e : employees) {
            e.showData();
            System.out.println("--------------------");
        }

        System.out.println("\n=== Gaji Karyawan (Dengan Bonus) ===");
        for (Employee e : employees) {
            System.out.println(e.name + " - Total Salary: " + e.calculateSalary(true));
        }
    }
}
