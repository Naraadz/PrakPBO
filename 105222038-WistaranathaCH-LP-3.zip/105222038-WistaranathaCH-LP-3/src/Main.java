public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World");

        double myDouble = 5.0 / 2.0;
        System.out.println(myDouble);
        int b = (int) 2.9 + (int) 1.8;
        System.out.println(b);

        System.out.println((double) 10 / 4);
        System.out.println(10 / 4.0);
        System.out.println(10 % 4); // modulus

        int x = 1;
        System.out.println(x++);
        // System.out.println(x)
        System.out.println(++x); // jika x++ di balik
        System.out.println(x++);

        int y =  10;
        y += 3; // 
        System.out.println(y);

    }

}
