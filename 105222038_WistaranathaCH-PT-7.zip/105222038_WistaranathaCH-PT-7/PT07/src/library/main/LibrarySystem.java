package library.main;

import java.util.ArrayList;

import library.model.Book;
import library.model.Member;

public class LibrarySystem {
    private ArrayList<Book> books;
    private ArrayList<Member> members;

    public LibrarySystem() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public void tampilkanBooks() {
        System.out.println("Daftar Buku:");
        for (Book book : books) {
            System.out.println("- " + book.getTitle() + " oleh " + book.getAuthor() + " (" + book.getYearPublished() + ")");
        }
    }

    public void tampilkanMembers() {
        System.out.println("Daftar Anggota:");
        for (Member member : members) {
            System.out.println("- " + member.getName() + " (ID: " + member.getMemberId() + ")");
        }
    }
    public static void main(String[] args) {
        LibrarySystem system = new LibrarySystem();

        system.addBook(new Book("omniscient reader's viewpoint", "Sing Shong", 2022));
        system.addBook(new Book("Kamar nomor 7", "Hazzahra", 2022));

        system.addMember(new Member("Dokja", "101"));
        system.addMember(new Member("Renji", "102"));

        system.tampilkanBooks();
        system.tampilkanMembers();
    }
}